import { Routes, Route, Navigate, NavLink, useLocation } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import {
  LayoutDashboard, Users, BookOpen, Building2, BarChart3,
  Settings, LogOut, Shield, GraduationCap, Menu, X
} from 'lucide-react';
import { useState } from 'react';

import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Trainees from './pages/Trainees.jsx';
import Courses from './pages/Courses.jsx';
import Specialties from './pages/Specialties.jsx';
import UsersPage from './pages/Users.jsx';

function ProtectedLayout({ children }) {
  const { user, loading, logout } = useAuth();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 rounded-full bg-primary animate-pulse" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;

  const nav = [
    { to: '/', icon: LayoutDashboard, label: 'لوحة التحكم', label_en: 'Dashboard' },
    { to: '/trainees', icon: Users, label: 'المتدربون', label_en: 'Trainees' },
    { to: '/courses', icon: BookOpen, label: 'الدورات وورش العمل', label_en: 'Courses' },
    { to: '/specialties', icon: GraduationCap, label: 'التخصصات', label_en: 'Specialties' },
    ...(user.role === 'ADMIN' ? [{ to: '/users', icon: Shield, label: 'المستخدمون', label_en: 'Users' }] : []),
  ];

  return (
    <div className="min-h-screen flex" dir="rtl">
      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 right-0 z-40 w-64 bg-white border-l border-gray-200 transform transition-transform ${mobileOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}`}>
        <div className="p-5 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-indigo flex items-center justify-center text-white font-display font-bold text-lg">M</div>
            <div>
              <div className="font-display font-bold text-lg leading-tight">MedTrain</div>
              <div className="text-[11px] text-gray-500">تجمع جازان الصحي</div>
            </div>
          </div>
        </div>
        <nav className="p-3 space-y-1">
          {nav.map((item) => (
            <NavLink key={item.to} to={item.to} end={item.to === '/'}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition ${
                  isActive ? 'bg-primary text-white' : 'text-gray-600 hover:bg-gray-50'
                }`}>
              <item.icon size={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="absolute bottom-0 inset-x-0 p-3 border-t border-gray-100">
          <div className="px-3 py-2 mb-2">
            <div className="text-sm font-semibold">{user.name}</div>
            <div className="text-[11px] text-gray-500">{roleLabel(user.role)}</div>
          </div>
          <button onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-rose hover:bg-rose/5 transition">
            <LogOut size={18} /> تسجيل الخروج
          </button>
        </div>
      </aside>

      {mobileOpen && <div className="fixed inset-0 bg-black/30 z-30 lg:hidden" onClick={() => setMobileOpen(false)} />}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center px-4 lg:px-6 gap-4">
          <button className="lg:hidden" onClick={() => setMobileOpen(true)}><Menu size={22} /></button>
          <div className="flex-1" />
          <div className="text-sm text-gray-500">{new Date().toLocaleDateString('ar-SA')}</div>
        </header>
        <main className="flex-1 p-4 lg:p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
}

function roleLabel(role) {
  return { ADMIN: 'مدير النظام', COORDINATOR: 'منسق', TRAINER: 'مدرب', VIEWER: 'مُطّلع' }[role] || role;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<ProtectedLayout><Dashboard /></ProtectedLayout>} />
      <Route path="/trainees" element={<ProtectedLayout><Trainees /></ProtectedLayout>} />
      <Route path="/courses" element={<ProtectedLayout><Courses /></ProtectedLayout>} />
      <Route path="/specialties" element={<ProtectedLayout><Specialties /></ProtectedLayout>} />
      <Route path="/users" element={<ProtectedLayout><UsersPage /></ProtectedLayout>} />
    </Routes>
  );
}
