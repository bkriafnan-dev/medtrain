import { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../lib/api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('medtrain_token');
    if (!token) { setLoading(false); return; }
    api.me()
      .then((res) => setUser(res.user))
      .catch(() => localStorage.removeItem('medtrain_token'))
      .finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    const res = await api.login(email, password);
    localStorage.setItem('medtrain_token', res.token);
    setUser(res.user);
    return res.user;
  };

  const logout = () => {
    localStorage.removeItem('medtrain_token');
    setUser(null);
    window.location.href = '/login';
  };

  // Role helpers
  const can = (action) => {
    if (!user) return false;
    const role = user.role;
    const rules = {
      editTrainee: ['ADMIN', 'COORDINATOR'],
      deleteTrainee: ['ADMIN'],
      manageCourses: ['ADMIN', 'COORDINATOR', 'TRAINER'],
      manageUsers: ['ADMIN'],
      import: ['ADMIN', 'COORDINATOR'],
      viewAudit: ['ADMIN'],
    };
    return (rules[action] || []).includes(role);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, can }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
