import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { Plus, Calendar, User, Trash2, X } from 'lucide-react';

export default function Courses() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const [year, setYear] = useState('');
  const [showForm, setShowForm] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['courses', year],
    queryFn: () => api.getCourses(year),
  });
  const delMut = useMutation({
    mutationFn: api.deleteCourse,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['courses'] }),
  });

  const courses = data?.data || [];
  // Group by pathway
  const byPathway = {};
  courses.forEach((c) => {
    const p = c.pathway || 'دورات عامة';
    (byPathway[p] = byPathway[p] || []).push(c);
  });

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display font-bold text-2xl">الدورات وورش العمل</h1>
          <p className="text-gray-500 text-sm">{courses.length} نشاط تدريبي</p>
        </div>
        <div className="flex gap-3">
          <select value={year} onChange={(e) => setYear(e.target.value)}
            className="px-4 py-2.5 rounded-xl border border-gray-200 outline-none bg-white text-sm">
            <option value="">كل السنوات</option>
            {[2024, 2025, 2026, 2027].map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
          {can('manageCourses') && (
            <button onClick={() => setShowForm(true)}
              className="bg-primary text-white px-4 py-2.5 rounded-xl flex items-center gap-2 text-sm font-semibold hover:bg-primary-dark">
              <Plus size={18} /> إضافة نشاط
            </button>
          )}
        </div>
      </div>

      {isLoading ? <div className="text-gray-400">جاري التحميل...</div> :
        Object.keys(byPathway).sort().map((pathway) => (
          <div key={pathway}>
            <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
              {pathway} <span className="text-xs bg-gray-100 px-2 py-0.5 rounded-full text-gray-500">{byPathway[pathway].length}</span>
            </h3>
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden mb-6">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="text-right px-4 py-3 font-semibold w-28">التاريخ</th>
                    <th className="text-right px-4 py-3 font-semibold">الموضوع</th>
                    <th className="text-right px-4 py-3 font-semibold">المتحدث</th>
                    <th className="text-right px-4 py-3 font-semibold">القسم</th>
                    {can('manageCourses') && <th className="px-4 py-3"></th>}
                  </tr>
                </thead>
                <tbody>
                  {byPathway[pathway].sort((a, b) => (a.date || '').localeCompare(b.date || '')).map((c) => (
                    <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                      <td className="px-4 py-3 font-medium text-xs">{c.date || '-'}</td>
                      <td className="px-4 py-3 font-medium">{c.title}</td>
                      <td className="px-4 py-3 text-gray-600">{c.speaker || '-'}</td>
                      <td className="px-4 py-3 text-gray-600">{c.department || '-'}</td>
                      {can('manageCourses') && (
                        <td className="px-4 py-3 text-left">
                          <button onClick={() => { if (confirm('حذف؟')) delMut.mutate(c.id); }}
                            className="p-1.5 rounded-lg hover:bg-rose/10 text-rose"><Trash2 size={15} /></button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}

      {showForm && <CourseForm onClose={() => setShowForm(false)}
        onSaved={() => { setShowForm(false); qc.invalidateQueries({ queryKey: ['courses'] }); }} />}
    </div>
  );
}

function CourseForm({ onClose, onSaved }) {
  const [form, setForm] = useState({
    title: '', category: 'lecture', date: '', year: 2026,
    speaker: '', jobTitle: '', department: '', pathway: '',
  });
  const save = async () => {
    try { await api.createCourse(form); onSaved(); }
    catch (e) { alert('خطأ: ' + e.message); }
  };
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-lg p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display font-bold text-lg">إضافة نشاط</h3>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-sm font-medium mb-1.5">الموضوع</label>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">التاريخ</label>
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">السنة</label>
            <input type="number" value={form.year} onChange={(e) => setForm({ ...form, year: parseInt(e.target.value) })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">المتحدث</label>
            <input value={form.speaker} onChange={(e) => setForm({ ...form, speaker: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">المسمى الوظيفي</label>
            <input value={form.jobTitle} onChange={(e) => setForm({ ...form, jobTitle: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">القسم</label>
            <input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">المسار</label>
            <input value={form.pathway} onChange={(e) => setForm({ ...form, pathway: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-gray-200 font-medium hover:bg-gray-50">إلغاء</button>
          <button onClick={save} disabled={!form.title}
            className="flex-1 py-2.5 rounded-xl bg-primary text-white font-semibold hover:bg-primary-dark disabled:opacity-50">حفظ</button>
        </div>
      </div>
    </div>
  );
}
