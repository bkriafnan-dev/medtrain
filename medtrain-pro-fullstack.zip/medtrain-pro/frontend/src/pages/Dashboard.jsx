import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { Users, BookOpen, Building2, GraduationCap } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

const PROGRAM_LABELS = {
  internship: 'الامتياز', students: 'تدريب طلاب', scfhs: 'الأقسام',
  fellowship: 'الزمالة', specialty: 'شهادة تخصص', residency: 'مقيم',
  admin: 'إداري', orientation: 'تهيئة',
};
const COLORS = ['#0d8e7f', '#5b67e0', '#f0a23a', '#8a5be0', '#2faf6e', '#e25c6e', '#06b6d4', '#ec4899'];

export default function Dashboard() {
  const { data: dash, isLoading } = useQuery({ queryKey: ['dashboard'], queryFn: api.getDashboard });
  const { data: specData } = useQuery({ queryKey: ['by-specialty'], queryFn: api.getBySpecialty });

  if (isLoading) return <div className="text-gray-400">جاري التحميل...</div>;

  const stats = [
    { label: 'إجمالي المتدربين', value: dash?.totalTrainees || 0, icon: Users, color: '#0d8e7f' },
    { label: 'الدورات وورش العمل', value: dash?.totalCourses || 0, icon: BookOpen, color: '#5b67e0' },
    { label: 'جلسات التهيئة', value: dash?.totalOrientation || 0, icon: Building2, color: '#f0a23a' },
    { label: 'التخصصات', value: dash?.bySpecialtyCount || 0, icon: GraduationCap, color: '#8a5be0' },
  ];

  const programData = (dash?.byProgram || [])
    .map((p) => ({ name: PROGRAM_LABELS[p.program] || p.program, value: p.count }))
    .sort((a, b) => b.value - a.value);

  const topSpecialties = (specData?.data || [])
    .sort((a, b) => b.count - a.count).slice(0, 10)
    .map((s) => ({ name: s.name_ar, value: s.count, color: s.color }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-2xl">لوحة التحكم</h1>
        <p className="text-gray-500 text-sm">نظرة عامة على بيانات قسم التدريب</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="bg-white rounded-2xl border border-gray-100 p-5">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: `${s.color}18`, color: s.color }}>
              <s.icon size={20} />
            </div>
            <div className="font-display font-bold text-3xl" style={{ color: s.color }}>{s.value.toLocaleString()}</div>
            <div className="text-sm text-gray-500 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Programs pie */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          <h3 className="font-semibold mb-4">التوزيع حسب البرنامج</h3>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={programData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label={(e) => e.name}>
                {programData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Top specialties bar */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          <h3 className="font-semibold mb-4">أكبر 10 تخصصات</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={topSpecialties} layout="vertical" margin={{ right: 20 }}>
              <XAxis type="number" hide />
              <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="value" radius={[0, 6, 6, 0]}>
                {topSpecialties.map((s, i) => <Cell key={i} fill={s.color || COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
