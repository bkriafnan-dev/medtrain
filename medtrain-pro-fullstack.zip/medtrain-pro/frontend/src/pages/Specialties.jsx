import { useQuery } from '@tanstack/react-query';
import { api } from '../lib/api.js';

export default function Specialties() {
  const { data, isLoading } = useQuery({ queryKey: ['by-specialty'], queryFn: api.getBySpecialty });
  const specialties = (data?.data || []).sort((a, b) => b.count - a.count);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-display font-bold text-2xl">التخصصات</h1>
        <p className="text-gray-500 text-sm">{specialties.length} تخصص نشط</p>
      </div>
      {isLoading ? <div className="text-gray-400">جاري التحميل...</div> : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {specialties.map((s) => (
            <div key={s.id} className="bg-white rounded-2xl border border-gray-100 p-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="w-3 h-3 rounded-full" style={{ background: s.color }} />
                <span className="font-semibold text-sm">{s.name_en}</span>
              </div>
              <div className="font-display font-bold text-3xl" style={{ color: s.color }}>{s.count.toLocaleString()}</div>
              <div className="text-sm text-gray-500 mt-1">{s.name_ar}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
