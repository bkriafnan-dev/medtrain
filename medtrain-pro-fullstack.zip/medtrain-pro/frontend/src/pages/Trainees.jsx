import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { Search, Plus, Edit2, Trash2, X, ChevronRight, ChevronLeft } from 'lucide-react';

const PROGRAMS = [
  { code: 'internship', label: 'الامتياز' }, { code: 'students', label: 'تدريب طلاب' },
  { code: 'scfhs', label: 'الأقسام' }, { code: 'fellowship', label: 'الزمالة' },
  { code: 'specialty', label: 'شهادة تخصص' }, { code: 'residency', label: 'مقيم' },
  { code: 'admin', label: 'إداري' }, { code: 'orientation', label: 'تهيئة' },
];

export default function Trainees() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [program, setProgram] = useState('');
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['trainees', page, search, program],
    queryFn: () => api.getTrainees({ page, limit: 50, search, program }),
  });

  const deleteMut = useMutation({
    mutationFn: api.deleteTrainee,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['trainees'] }),
  });

  const trainees = data?.data || [];
  const pagination = data?.pagination || {};

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display font-bold text-2xl">المتدربون</h1>
          <p className="text-gray-500 text-sm">{(pagination.total || 0).toLocaleString()} متدرب</p>
        </div>
        {can('editTrainee') && (
          <button onClick={() => { setEditing(null); setShowForm(true); }}
            className="bg-primary text-white px-4 py-2.5 rounded-xl flex items-center gap-2 text-sm font-semibold hover:bg-primary-dark transition">
            <Plus size={18} /> إضافة متدرب
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="بحث بالاسم..."
            className="w-full pr-10 pl-4 py-2.5 rounded-xl border border-gray-200 focus:border-primary outline-none text-sm" />
        </div>
        <select value={program} onChange={(e) => { setProgram(e.target.value); setPage(1); }}
          className="px-4 py-2.5 rounded-xl border border-gray-200 focus:border-primary outline-none text-sm bg-white">
          <option value="">كل البرامج</option>
          {PROGRAMS.map((p) => <option key={p.code} value={p.code}>{p.label}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-right px-4 py-3 font-semibold">الاسم</th>
                <th className="text-right px-4 py-3 font-semibold">التخصص</th>
                <th className="text-right px-4 py-3 font-semibold">البرنامج</th>
                <th className="text-right px-4 py-3 font-semibold">الحالة</th>
                {can('editTrainee') && <th className="px-4 py-3"></th>}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr><td colSpan={5} className="text-center py-12 text-gray-400">جاري التحميل...</td></tr>
              ) : trainees.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-12 text-gray-400">لا توجد نتائج</td></tr>
              ) : trainees.map((t) => (
                <tr key={t.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                  <td className="px-4 py-3 font-medium">{t.name}</td>
                  <td className="px-4 py-3 text-gray-600">
                    {t.specialty && (
                      <span className="inline-flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full" style={{ background: t.specialty.color }} />
                        {t.specialty.nameAr}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-gray-600">{PROGRAMS.find((p) => p.code === t.programCode)?.label || t.programCode}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${t.status === 'ACTIVE' ? 'bg-emerald/10 text-emerald' : 'bg-gray-100 text-gray-500'}`}>
                      {t.status === 'ACTIVE' ? 'نشط' : t.status === 'COMPLETED' ? 'مكتمل' : 'غير نشط'}
                    </span>
                  </td>
                  {can('editTrainee') && (
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-end">
                        <button onClick={() => { setEditing(t); setShowForm(true); }} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"><Edit2 size={15} /></button>
                        {can('deleteTrainee') && (
                          <button onClick={() => { if (confirm(`حذف ${t.name}؟`)) deleteMut.mutate(t.id); }}
                            className="p-1.5 rounded-lg hover:bg-rose/10 text-rose"><Trash2 size={15} /></button>
                        )}
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pagination.pages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <span className="text-sm text-gray-500">صفحة {pagination.page} من {pagination.pages}</span>
            <div className="flex gap-2">
              <button disabled={page <= 1} onClick={() => setPage(page - 1)}
                className="p-2 rounded-lg border border-gray-200 disabled:opacity-40 hover:bg-gray-50"><ChevronRight size={16} /></button>
              <button disabled={page >= pagination.pages} onClick={() => setPage(page + 1)}
                className="p-2 rounded-lg border border-gray-200 disabled:opacity-40 hover:bg-gray-50"><ChevronLeft size={16} /></button>
            </div>
          </div>
        )}
      </div>

      {showForm && <TraineeForm trainee={editing} onClose={() => setShowForm(false)}
        onSaved={() => { setShowForm(false); qc.invalidateQueries({ queryKey: ['trainees'] }); }} />}
    </div>
  );
}

function TraineeForm({ trainee, onClose, onSaved }) {
  const [form, setForm] = useState({
    name: trainee?.name || '',
    programCode: trainee?.programCode || 'internship',
    email: trainee?.email || '',
    mobile: trainee?.mobile || '',
    nationalId: trainee?.nationalId || '',
    university: trainee?.university || '',
    status: trainee?.status || 'ACTIVE',
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      if (trainee) await api.updateTrainee(trainee.id, form);
      else await api.createTrainee(form);
      onSaved();
    } catch (err) {
      alert('خطأ: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-lg p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display font-bold text-lg">{trainee ? 'تعديل متدرب' : 'إضافة متدرب'}</h3>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Field label="الاسم" full value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          <div className="col-span-2">
            <label className="block text-sm font-medium mb-1.5">البرنامج</label>
            <select value={form.programCode} onChange={(e) => setForm({ ...form, programCode: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary bg-white">
              {PROGRAMS.map((p) => <option key={p.code} value={p.code}>{p.label}</option>)}
            </select>
          </div>
          <Field label="البريد" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
          <Field label="الجوال" value={form.mobile} onChange={(v) => setForm({ ...form, mobile: v })} />
          <Field label="رقم الهوية" value={form.nationalId} onChange={(v) => setForm({ ...form, nationalId: v })} />
          <Field label="الجامعة" value={form.university} onChange={(v) => setForm({ ...form, university: v })} />
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-gray-200 font-medium hover:bg-gray-50">إلغاء</button>
          <button onClick={save} disabled={saving || !form.name}
            className="flex-1 py-2.5 rounded-xl bg-primary text-white font-semibold hover:bg-primary-dark disabled:opacity-50">
            {saving ? 'جاري الحفظ...' : 'حفظ'}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, full }) {
  return (
    <div className={full ? 'col-span-2' : ''}>
      <label className="block text-sm font-medium mb-1.5">{label}</label>
      <input value={value} onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
    </div>
  );
}
