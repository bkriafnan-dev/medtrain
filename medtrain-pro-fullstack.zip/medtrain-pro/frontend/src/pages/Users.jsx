import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../lib/api.js';
import { Plus, Shield, X } from 'lucide-react';

const ROLES = [
  { value: 'ADMIN', label: 'مدير النظام' }, { value: 'COORDINATOR', label: 'منسق' },
  { value: 'TRAINER', label: 'مدرب' }, { value: 'VIEWER', label: 'مُطّلع' },
];

export default function Users() {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const { data, isLoading } = useQuery({ queryKey: ['users'], queryFn: api.getUsers });
  const users = data?.data || [];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-2xl">المستخدمون</h1>
          <p className="text-gray-500 text-sm">{users.length} مستخدم</p>
        </div>
        <button onClick={() => setShowForm(true)}
          className="bg-primary text-white px-4 py-2.5 rounded-xl flex items-center gap-2 text-sm font-semibold hover:bg-primary-dark">
          <Plus size={18} /> إضافة مستخدم
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              <th className="text-right px-4 py-3 font-semibold">الاسم</th>
              <th className="text-right px-4 py-3 font-semibold">البريد</th>
              <th className="text-right px-4 py-3 font-semibold">الصلاحية</th>
              <th className="text-right px-4 py-3 font-semibold">آخر دخول</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? <tr><td colSpan={4} className="text-center py-12 text-gray-400">جاري التحميل...</td></tr> :
              users.map((u) => (
                <tr key={u.id} className="border-b border-gray-50">
                  <td className="px-4 py-3 font-medium">{u.name}</td>
                  <td className="px-4 py-3 text-gray-600">{u.email}</td>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium bg-indigo/10 text-indigo">
                      <Shield size={12} /> {ROLES.find((r) => r.value === u.role)?.label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-500 text-xs">{u.lastLogin ? new Date(u.lastLogin).toLocaleDateString('ar-SA') : 'لم يدخل'}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      {showForm && <UserForm onClose={() => setShowForm(false)}
        onSaved={() => { setShowForm(false); qc.invalidateQueries({ queryKey: ['users'] }); }} />}
    </div>
  );
}

function UserForm({ onClose, onSaved }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'VIEWER' });
  const save = async () => {
    try { await api.createUser(form); onSaved(); }
    catch (e) { alert('خطأ: ' + e.message); }
  };
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl w-full max-w-md p-6" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-display font-bold text-lg">إضافة مستخدم</h3>
          <button onClick={onClose}><X size={20} /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1.5">الاسم</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">البريد الإلكتروني</label>
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">كلمة المرور</label>
            <input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary" />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">الصلاحية</label>
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-primary bg-white">
              {ROLES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-gray-200 font-medium hover:bg-gray-50">إلغاء</button>
          <button onClick={save} disabled={!form.name || !form.email || !form.password}
            className="flex-1 py-2.5 rounded-xl bg-primary text-white font-semibold hover:bg-primary-dark disabled:opacity-50">حفظ</button>
        </div>
      </div>
    </div>
  );
}
