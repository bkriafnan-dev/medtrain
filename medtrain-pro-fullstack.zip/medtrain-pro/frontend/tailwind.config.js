export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#0d8e7f',
        'primary-dark': '#0a7268',
        indigo: '#5b67e0',
        emerald: '#2faf6e',
        amber: '#f0a23a',
        rose: '#e25c6e',
        violet: '#8a5be0',
      },
      fontFamily: {
        display: ['Fraunces', 'serif'],
        sans: ['Manrope', 'system-ui', 'sans-serif'],
        arabic: ['Cairo', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
