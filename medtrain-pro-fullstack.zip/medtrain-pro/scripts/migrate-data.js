/**
 * MedTrain Pro — Data Migration Script
 *
 * Imports your existing master backup (medtrain-MASTER-*.json)
 * into the PostgreSQL database.
 *
 * Usage:
 *   1. Place your medtrain-MASTER-*.json in this folder
 *   2. Run: node migrate-data.js path/to/medtrain-MASTER.json
 *
 * This migrates: trainees, specialties, program types, courses,
 * orientation sessions, attendance proofs.
 * Large files (images/PDFs) need separate S3 upload (see uploadFiles.js).
 */

const { PrismaClient } = require('@prisma/client');
const fs = require('fs');
const path = require('path');

const prisma = new PrismaClient();

// Map old status strings to enum
function mapStatus(s) {
  const v = (s || 'active').toLowerCase();
  if (v === 'completed') return 'COMPLETED';
  if (v === 'inactive') return 'INACTIVE';
  return 'ACTIVE';
}

async function main() {
  const filePath = process.argv[2];
  if (!filePath) {
    console.error('Usage: node migrate-data.js <path-to-master-backup.json>');
    process.exit(1);
  }

  console.log('Reading master backup:', filePath);
  const master = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  const data = master.data || master;

  console.log('\n=== Migration Starting ===');
  console.log('Trainees:', (data.trainees || []).length);
  console.log('Courses:', (data.course_uploads || []).length);
  console.log('Orientation:', (data.orientation_sessions || []).length);
  console.log('Proofs:', (data.attendance_proofs || []).length);

  // ============================================================
  // 1) Specialties
  // ============================================================
  console.log('\n[1/7] Migrating specialties...');
  const specialtyMap = {}; // old name_en -> new id
  for (const sp of (data.specialties || [])) {
    const created = await prisma.specialty.create({
      data: {
        nameEn: sp.name_en || sp.nameEn || 'Unknown',
        nameAr: sp.name_ar || sp.nameAr || sp.name_en || 'Unknown',
        color: sp.color || '#0d8e7f',
      },
    });
    specialtyMap[created.nameEn] = created.id;
  }
  console.log('  ✓', Object.keys(specialtyMap).length, 'specialties');

  // ============================================================
  // 2) Program Types
  // ============================================================
  console.log('[2/7] Migrating program types...');
  const programMap = {}; // code -> id
  for (const p of (data.program_types || [])) {
    const created = await prisma.programType.upsert({
      where: { code: p.code },
      update: {},
      create: {
        code: p.code,
        nameEn: p.en || p.name_en || p.code,
        nameAr: p.ar || p.name_ar || p.code,
        color: p.color || '#5b67e0',
        paid: !!p.paid,
      },
    });
    programMap[p.code] = created.id;
  }
  console.log('  ✓', Object.keys(programMap).length, 'program types');

  // ============================================================
  // 3) Trainees (batched for performance)
  // ============================================================
  console.log('[3/7] Migrating trainees...');
  const trainees = data.trainees || [];
  let migrated = 0;
  const BATCH = 200;

  for (let i = 0; i < trainees.length; i += BATCH) {
    const batch = trainees.slice(i, i + BATCH);
    await prisma.trainee.createMany({
      data: batch.map(t => ({
        name: t.name || 'Unknown',
        specialtyId: specialtyMap[t.specialty] || null,
        programTypeId: programMap[t.program_type] || null,
        programCode: t.program_type || 'other',
        status: mapStatus(t.status),
        gender: t.gender || 'male',
        email: t.email || null,
        mobile: t.mobile || null,
        nationalId: t.national_id || null,
        university: t.university || null,
        startDate: t.start_date || null,
        endDate: t.end_date || null,
        paid: !!t.paid,
        revenue: parseFloat(t.revenue) || 0,
        scfhsNo: t.scfhs_no || null,
        scfhsExpiry: t.scfhs_expiry || null,
        cprExpiry: t.cpr_expiry || null,
        aclsExpiry: t.acls_expiry || null,
        palsExpiry: t.pals_expiry || null,
        atlsExpiry: t.atls_expiry || null,
        certs: t.certs || {},
        source: t.import_sheet || t.source || null,
        notes: t.notes || null,
      })),
      skipDuplicates: true,
    });
    migrated += batch.length;
    process.stdout.write(`\r  Migrating: ${migrated}/${trainees.length}`);
  }
  console.log('\n  ✓', migrated, 'trainees');

  // ============================================================
  // 4) Courses
  // ============================================================
  console.log('[4/7] Migrating courses...');
  let courseCount = 0;
  for (const c of (data.course_uploads || [])) {
    await prisma.course.create({
      data: {
        title: c.title || 'Untitled',
        category: c.category || 'course',
        date: c.date || null,
        year: parseInt(c.year) || 2026,
        sessions: parseInt(c.sessions) || 1,
        totalAttendance: parseInt(c.total_attendance || c.attendees) || 0,
        speaker: c.speaker || c.instructor || null,
        jobTitle: c.job_title || null,
        department: c.department || null,
        pathway: c.pathway || null,
        hospital: c.hospital || null,
        description: c.description || null,
        source: c.source || null,
      },
    });
    courseCount++;
  }
  console.log('  ✓', courseCount, 'courses');

  // ============================================================
  // 5) Orientation Sessions
  // ============================================================
  console.log('[5/7] Migrating orientation sessions...');
  let orientCount = 0;
  for (const o of (data.orientation_sessions || [])) {
    await prisma.orientationSession.create({
      data: {
        title: o.title || o.name || 'Session',
        date: o.date || null,
        year: parseInt(o.year) || 2026,
        attendees: parseInt(o.attendees) || 0,
        notes: o.notes || null,
      },
    });
    orientCount++;
  }
  console.log('  ✓', orientCount, 'orientation sessions');

  // ============================================================
  // 6) Attendance Proofs (metadata only; files go to S3 separately)
  // ============================================================
  console.log('[6/7] Migrating attendance proofs (metadata)...');
  let proofCount = 0;
  for (const p of (data.attendance_proofs || [])) {
    await prisma.attendanceProof.create({
      data: {
        title: p.title || p.filename || 'Proof',
        year: parseInt(p.year) || 2026,
        linkedCourseId: null, // course IDs differ after migration; relink manually if needed
      },
    });
    proofCount++;
  }
  console.log('  ✓', proofCount, 'attendance proofs (files need separate S3 upload)');

  // ============================================================
  // 7) Default admin user
  // ============================================================
  console.log('[7/7] Creating default admin user...');
  const bcrypt = require('bcryptjs');
  const adminEmail = 'admin@jazan.health.sa';
  const existing = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existing) {
    await prisma.user.create({
      data: {
        email: adminEmail,
        passwordHash: await bcrypt.hash('ChangeMe123!', 10),
        name: 'System Administrator',
        role: 'ADMIN',
      },
    });
    console.log('  ✓ Admin created: admin@jazan.health.sa / ChangeMe123!');
    console.log('  ⚠️  CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN');
  } else {
    console.log('  ✓ Admin already exists');
  }

  console.log('\n=== Migration Complete ===');
}

main()
  .catch(e => {
    console.error('Migration failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
